<?php
//Database credentials
	
	define('SERVER', 'cs.ashesi.edu.gh');
	define('DATABASE', 'webtech_fall2019_najahat_antiku');
	define('USERNAME', 'najahat_antiku');
	define('PASSWD', 'najahat_antiku');

// create connection
	$connection = mysqli_connect(SERVER,USERNAME,PASSWD,DATABASE);


// Check connection
	if (!$connection) {
		die("Connection failed: " . mysqli_connect_error());
	} 
	// else {
	// 	echo "connected to database";
	// }
?>