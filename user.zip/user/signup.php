<!DOCTYPE html>
<html>
<head>
  <title>Sign Up </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="signup.css">
  <script type="text/javascript" src = noduplicates.js></script>
  <script src="jquery-3.2.1.min.js"></script>
 
</head>
<body>
  <div class="form-style-10">
    <h1>Sign Up!<span>Sign up and give us monthly updates on your journey as a mentor</span></h1>
    <form action = "connectsignup.php" method = "POST">
    <script>
        function lettersOnly(input){
            var regex = /[^a-z]/gi;
            input.value = input.value.replace(regex,"");
        }
        
    </script>
        <!-- <form action = "process.php" method = "POST"> -->
        <div class="section"><span>1</span>Username</div>
        <div class="inner-wrap">
            <label>Firstname <input type="text" name="fname" onkeyup = "lettersOnly(this)" required/></label>
            <label>Surname <input type="text" name="lname" onkeyup = "lettersOnly(this)" required/></label>
            <label>Username <input type="text" name="uname" id = "uname" onkeyup = "lettersOnly(this)" required/></label>
            
        </div>

        <div class="section"><span>2</span>Email & Phone</div>
        <div class="inner-wrap">
            <label>Email Address <input type="email" name="email" id ="email" pattern = "[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"/></label>
            <label>Phone Number <input type="text" name="phone" id= "num" maxlength = "10" required /></label>
        </div>

        <div class="section"><span>3</span>Passwords</div>
            <div class="inner-wrap">
            <label>Password <input type="password" name="pass" id = "pass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required/></label>
            <label>Confirm Password <input type="password" name="cpass" id = "cpass"/></label>
        </div>
        <div class="button-section">
         <input type="submit" name="SignUp" value = "Sign Up" id = "signup" />
        </div>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
        <script type="text/javascript">
            $(function () {
                $("#signup").click(function () {
                    var password = $("#pass").val();
                    var confirmPassword = $("#cpass").val();
                    if (password != confirmPassword) {
                        alert("Passwords do not match.");
                        return false;
                    }
                    return true;
                });
            });
        </script>
      </form>
        </div>
        <div id="message">
          <h3>Password must contain the following:</h3>
          <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
          <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
          <p id="number" class="invalid">A <b>number</b></p>
          <p id="length" class="invalid">Minimum <b>8 characters</b></p>
        </div>
        <script>
            var myInput = document.getElementById("pass");
            var letter = document.getElementById("letter");
            var capital = document.getElementById("capital");
            var number = document.getElementById("number");
            var length = document.getElementById("length");

            // When the user clicks on the password field, show the message box
            myInput.onfocus = function() {
              document.getElementById("message").style.display = "block";
            }

            // When the user clicks outside of the password field, hide the message box
            myInput.onblur = function() {
              document.getElementById("message").style.display = "none";
            }

            // When the user starts to type something inside the password field
            myInput.onkeyup = function() {
              // Validate lowercase letters
              var lowerCaseLetters = /[a-z]/g;
              if(myInput.value.match(lowerCaseLetters)) {
                letter.classList.remove("invalid");
                letter.classList.add("valid");
              } else {
                letter.classList.remove("valid");
                letter.classList.add("invalid");
            }

              // Validate capital letters
              var upperCaseLetters = /[A-Z]/g;
              if(myInput.value.match(upperCaseLetters)) {
                capital.classList.remove("invalid");
                capital.classList.add("valid");
              } else {
                capital.classList.remove("valid");
                capital.classList.add("invalid");
              }

              // Validate numbers
              var numbers = /[0-9]/g;
              if(myInput.value.match(numbers)) {
                number.classList.remove("invalid");
                number.classList.add("valid");
              } else {
                number.classList.remove("valid");
                number.classList.add("invalid");
              }

              // Validate length
              if(myInput.value.length >= 8) {
                length.classList.remove("invalid");
                length.classList.add("valid");
              } else {
                length.classList.remove("valid");
                length.classList.add("invalid");
              }
            }
    </script>
  



    </form>
    </div>

</body>
</html>