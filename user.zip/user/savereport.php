<?php 
	require('db_connect.php'); 

	if( isset( $_POST['submit'])) {
		$Mentor = ($_POST['mentor']);
		$Mentee = ($_POST['mentee']);
		$Theme = ($_POST['theme']);
		$Date = ($_POST['date']);
		$Report = ($_POST['report']);
		$Next = ($_POST['next']);
		$Comments = ($_POST['comments']);
		
		
		$sql1 = "INSERT INTO report(Name_of_Mentor, Name_of_Mentee, Theme_of_Month,Date_of_entry, Report, Next_Steps, Comments) VALUES ('$Mentor','$Mentee','$Theme','$Date','$Report', '$Next', '$Comments')";
		
		if (mysqli_query($connection, $sql1)) {
			
	    	
	    	header("Location: logout.php");
	    	
	    	
		} 

		else {
	    	echo "Error: " . $sql1 . "<br>" . mysqli_error($connection);
		}
	}

	

		mysqli_close($connection);
		

?>