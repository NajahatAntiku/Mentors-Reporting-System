<?php
	// start a session to store information to be used across multiple pages
	session_start();

	// require a database connection
	require('db_connect.php');

	function logUserOut() {

	}

	function sanitizeData($input) {
		$data = trim($input);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		
		return $data;

	
	}

	// check which button has been clicked
	// login button clicked
	if (isset($_POST['login'])) {
		// get the submitted username and password and sanitize them
		$name = sanitizeData($_POST['uname']);
		$pass = sanitizeData($_POST['Password']);

		// hash user password before looking it up in the database
		$pass_hash = md5($pass);
		
		
  		$sql = "SELECT * FROM user WHERE Username='$name' && Password='$pass_hash'";
		
		// $sql = "SELECT * FROM 'payment method' WHERE 'PaymentId' = '01'";
		// echo $sql;

		//run the query and store result
		$result = mysqli_query($connection, $sql);
		
		// check if results were retrieved
		// login successful
		if (mysqli_num_rows($result) > 0) {
	    	// fetch result as an array
	    	$row = mysqli_fetch_assoc($result);
	        
	        // set retrieved user information in a session variable to be used across multiple pages
	        $_SESSION['user_info'] = $row['Username'];


	        // redirect user to their dashboard as they have successfully logged in
	        header("Location: report.php");

			

		} else {
			// login failed
	    	// redirect user to login page again
	    	header("Location: index.php");
	    	
	    	
		}


  	}

		

		// close database connection
		mysqli_close($connection);
	
?>