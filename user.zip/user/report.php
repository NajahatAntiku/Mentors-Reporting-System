<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="report.css">
</head>
<body>
	<div class="form-style-5">
		<form method = "POST" action = "savereport.php">
		<fieldset>
			<legend><span class="number"></span> BML Mentorship Report</legend>
			<input type="text" name="mentor" placeholder="Name of Mentor" required>
			<input type="text" name="mentee" id = "mentor" placeholder="Name of Mentee " id = "mentee" required>
			<input type="text" name="theme" id = "theme" placeholder="Theme of the month " required>
			<input type="date" name="date" id="date" placeholder="Date" required>
			<textarea name="report" id = "report" placeholder="Report/Findings" required></textarea>
			<textarea name="next" id = "next" placeholder="Next steps" required></textarea>
			<textarea name="comments" id = "comments"placeholder="Comments/Suggestions"></textarea>
			<!-- <input type="file" name = "file"> -->
		</fieldset>
		<input type="submit" value="Submit" name = "submit" id = "submit" />
		</form>
		</div>

		
</script>
</body>
</html>