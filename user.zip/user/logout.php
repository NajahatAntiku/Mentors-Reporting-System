<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Logout</title>
	<link rel="stylesheet" type="text/css" href="logout.css">
</head>
<body>
	<?php
		echo "Entry Successful. Thanks for submitting your monthly report";
	?>
	<br>
	<br>
	<form action = "processlogout.php" method = "POST">
	<input type = "submit" name ="logout" id = "logout" value="Logout">

	</form>


</body>
</html>