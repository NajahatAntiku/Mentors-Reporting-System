<!DOCTYPE html>
<html>
<head>
	<title> Login </title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>
	<div class="login">
    <h1>Login</h1>
    <form method="POST" action = "process.php">
        
	    <div class="input_container">
	        <i class="fas fa-user"></i>
	        <input placeholder="Username" type="text" name="uname" id="field_name" class='input_field'>
	    </div>
	    <br>
	    <div class="input_container">
	        <i class="fas fa-lock"></i>
	        <input  placeholder="Password" type="password" name="Password" id="field_password" class='input_field'>
	    </div>
	    <br>
	    <input type="submit" value="Login" id='input_submit' class='input_field' name = 'login'>
	<br>
	<span>Forgot <a href="#"> Username / Password ?</a></span>
	<span id='create_account'>
		<br>
		<br>
		<br>
	    <a href="signup.php">New User? Create an account ➡ </a>
	</span>
	</div>
    </form>
</div>

</body>
</html>