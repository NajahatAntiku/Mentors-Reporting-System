<?php
	require('db_connect.php'); 
 //store variables
 	if( isset( $_POST['SignUp'])) {
 		$Firstname = ($_POST['fname']);
 		$Lastname = ($_POST['lname']);
		$Username = ($_POST['uname']);
		$email = ($_POST['email']);
		$phone = ($_POST['phone']);
		$password = ($_POST['pass']);
		

		$password = md5($password);
		

		$sql = "INSERT INTO user(Firstname, Lastname,Username,Email,Phone,Password) VALUES('$Firstname', '$Lastname','$Username','$email','$phone','$password')";
		
		if (mysqli_query($connection, $sql)) {
	    	echo "New record created successfully";
	    	header("Location:login.php");
		} 	
		else {
	    	echo "Error: " . $sql . "<br>" . mysqli_error($connection);
		}
	}

	
		mysqli_close($connection);
	
	
	


?>